﻿
#### Kontroller
- Esc: Quit Application
- t: Takeoff
- l: Land

##### AI Mode

- 0: mesafe 0
- 1: mesafe 1
- 2: mesafe 2
- 3: mesafe 3
- 4: mesafe 4
- 5: mesafe 5
- 6: mesafe 6

faceSizes = [0:1026, 1:684, 2:456, 3:304, 4:202, 5:136, 6:90]

##### Override Mode
- 8:	Enable / Disable Override mode
- W/S: 	Forward/Back
- A/D: 	Left/Right (yerinde dönşler)
- Q/E: 	Up/Down
- Z/C: 	Left/Right
- 1: 	Drone hızı 1
- 2: 	Drone hızı 2
- 3: 	Drone hızı 3

##### Not:
- Override disable: Yüz tespiti ve takip
- Override enable: Yüz tanıma ve klavye kontrolü

##### Run
- python app.py